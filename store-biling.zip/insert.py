from flask import Flask, render_template, request, redirect, url_for, flash, session
import mysql.connector
from mysql.connector import Error
import streamlit as st



app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a random secret key for sessions

# Database connection function
def create_connection():
    connection = None
    try:
        connection = mysql.connector.connect(
            host='localhost',
            user='root',      # Replace with your MySQL username
            password='',  # Replace with your MySQL password
            database='store'
        )
        if connection.is_connected():
            print("Connection successful")
    except Error as e:
        print(f"Error: '{e}'")
    return connection


@app.route('/')
def index():
    # Fetch existing products from the database
    connection = create_connection()
    cursor = connection.cursor(dictionary=True)
    cursor.execute("SELECT * FROM insert_data")
    products = cursor.fetchall()
    cursor.close()
    connection.close()
    
    return render_template('index_2.html', products=products)


if st.button('Bill Page'):
    st.markdown("[Click here to go to Bill Page](http://127.0.0.1:5000/)", unsafe_allow_html=True)


@app.route('/add_product', methods=['POST'])
def add_product():
    # Get form data
    product_id = request.form['product_id']
    product_name = request.form['product_name']
    product_category = request.form['product_category']
    product_quantity = request.form['product_quantity']
    product_price = request.form['product_price']

    # Insert product into the database
    connection = create_connection()
    cursor = connection.cursor()
    insert_query = """
    INSERT INTO insert_data (product_id, product_name, product_category, product_quantity, product_price)
    VALUES (%s, %s, %s, %s, %s)
    """
    try:
        cursor.execute(insert_query, (product_id, product_name, product_category, product_quantity, product_price))
        connection.commit()
        flash('Product added successfully!', 'success')
    except Error as e:
        flash('Error inserting product: ' + str(e), 'danger')
    finally:
        cursor.close()
        connection.close()

    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
