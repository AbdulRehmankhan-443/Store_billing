import mysql.connector
import streamlit as st
import pandas as pd
import webbrowser

# Database connection details
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'store'
}

def get_data():
    try:
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()
        cursor.execute("SELECT product_id, product_name, product_category, product_quantity, product_price FROM insert_data")
        results = cursor.fetchall()
        return pd.DataFrame(results, columns=['Product ID', 'Product Name', 'Product Category', 'Product Quantity', 'Product Price'])
    except mysql.connector.Error as err:
        st.error(f"Error: {err}")
        return pd.DataFrame()  # Return an empty DataFrame on error
    finally:
        cursor.close()
        connection.close()

def update_product_quantity(product_name, quantity):
    try:
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()
        cursor.execute(
            "UPDATE insert_data SET product_quantity = product_quantity - %s WHERE product_name = %s",
            (quantity, product_name)
        )
        connection.commit()
    except mysql.connector.Error as err:
        st.error(f"Error updating product quantity: {err}")
    finally:
        cursor.close()
        connection.close()

# Streamlit app with gradient background
st.markdown(
    """
    <style>
    .stApp {
      background: linear-gradient(to right, #87CEEB, #FF69B4);
      color: Black;
    }
    </style>
    """,
    unsafe_allow_html=True
)

if st.button("Add Products"):
    webbrowser.open("http://127.0.0.1:5000/")
st.title('🍏 Grocery Store 🍏')

# Fetch product data from the database
product_df = get_data()

# Customer input form
st.subheader('Customer Details')
with st.form(key='customer_form'):
    customer_name = st.text_input('Customer Name')
    customer_city = st.text_input('Customer City')
    customer_contact = st.text_input('Customer Contact Number')
    
    selected_products = st.multiselect('Select Products', product_df['Product Name'])
    quantities = {product: st.number_input(f'Quantity for {product}', min_value=1, max_value=100, value=1) for product in selected_products}

    # Calculate total bill
    total_bill = sum(product_df[product_df['Product Name'] == product]['Product Price'].values[0] * quantities[product] for product in selected_products)

    submit_button = st.form_submit_button('Calculate Total Bill')
    
    if submit_button:
        # Display customer details separately
        st.subheader('Customer Information')
        st.markdown(f"**Customer Name:** {customer_name}")
        st.markdown(f"**Customer City:** {customer_city}")
        st.markdown(f"**Contact Number:** {customer_contact}")

        # Prepare bill details for display
        bill_data = []
        for product in selected_products:
            qty = quantities[product]
            price = product_df[product_df['Product Name'] == product]['Product Price'].values[0]
            product_category = product_df[product_df['Product Name'] == product]['Product Category'].values[0]
            total_price = price * qty
            bill_data.append({
                'Product Name': product,
                'Product Category': product_category,
                'Quantity': qty,
                'Price per Unit': f"{price:}",
                'Total Price': f"{total_price:}"
            })

        bill_data.append({
            'Product Name': 'Total',
            'Product Category': '',
            'Quantity': '',
            'Price per Unit': '',
            'Total Price': f"{total_bill:}"
        })

        # Create DataFrame for the bill
        bill_df = pd.DataFrame(bill_data)

        # Display the bill in a structured table format
        st.subheader('Grocery Store Bill')
        st.table(bill_df)



        # Prepare the download DataFrame including customer details
        customer_data = {
            'Customer Name': [customer_name],
            'City': [customer_city],
            'Contact Number': [customer_contact]
        }
        customer_df = pd.DataFrame(customer_data)

        # Save the HTML for both tables separately with styles
        customer_html = customer_df.to_html(index=False, classes='customer-table')
        bill_html = bill_df.to_html(index=False, classes='bill-table')

        # Combine HTML for download with styling
        full_html = f"""
        <html>
        <head>
            <style>
                body {{
                    font-family: Helvetica, sans-serif;
                    width: 500;
                    border: 2px solid black;
                    margin: 1px; 
                    padding: 20px; 
                }}
                h3 {{
                    color: #0c4f70;
                }}
                .customer-table, .bill-table {{
                    border-collapse: collapse;
                    width: 500;
                    border: 2px solid black;
                    margin: 1px; 
                    padding: 20px; 
                }}
                .customer-table th, .bill-table th {{
                    background-color: #de1d3d;
                    color: white;
                    padding: 10px;
                }}
                .customer-table td, .bill-table td {{
                    border: 1px solid #ddd;
                    padding: 8px;
                }}
                .bill-table tr:nth-child(even) {{
                    background-color: #f2f2f2;
                }}
                .bill-table tr:hover {{
                    background-color: #ddd;
                }}
            </style>
        </head>
        <body>
            <h5>Thank you {customer_name} for purchasing from our store!</h5>
            <h3>Customer Information</h3>
            {customer_html}
            <h3>Grocery Store Bill</h3> 
            {bill_html}

        </body>
        </html>
        """

        st.session_state.bill_details = full_html

# Confirm purchase and update product quantities
if st.button('Confirm Purchase'):
    for product in selected_products:
        update_product_quantity(product, quantities[product])
    st.success("Purchase confirmed! Product quantities have been updated.")

# Add download button outside the form
if 'bill_details' in st.session_state:
    st.download_button(
        label="Download Bill",
        data=st.session_state.bill_details,
        file_name='Tech Specialist Store',
        mime='text/html'
    )

# Add a footer
st.markdown("---")
st.write(f"Thank you for visiting our grocery store!")
